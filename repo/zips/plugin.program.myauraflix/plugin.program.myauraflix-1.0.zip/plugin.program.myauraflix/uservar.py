import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflixrepo.000webhostapp.com/myauraflix/texts/Nexus_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflixrepo.000webhostapp.com/myauraflix/texts/wizard_notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
